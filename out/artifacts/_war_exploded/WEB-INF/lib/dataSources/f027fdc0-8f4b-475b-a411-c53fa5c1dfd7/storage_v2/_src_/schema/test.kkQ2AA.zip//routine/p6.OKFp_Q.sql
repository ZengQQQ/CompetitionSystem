create
    definer = root@localhost procedure p6(IN uage int)
begin
    declare u_name varchar(10);
    declare u_address varchar(10);
    declare c1 cursor for select name,address from user where age>uage;
    #条件处理程序会捕获存储过程中相应的报错，并执行后面的SQL语句,如这里的close c1
    declare exit handler for NOT FOUND close c1;
    #创建一张新表保存查询到的结果
    create table temp(
     id int primary key auto_increment,
     name varchar(10),
     address varchar(10)
    );
    open c1;
    #while后面的条件是true，当所有数据取完后会报错,必须要在循环外定义条件处理语句来处理报错，使程序正常进行
    while true do
    fetch c1 into u_name,u_address;
    insert into temp values (null,u_name,u_address);
    end while;
    close c1;
    select * from temp;
end;

