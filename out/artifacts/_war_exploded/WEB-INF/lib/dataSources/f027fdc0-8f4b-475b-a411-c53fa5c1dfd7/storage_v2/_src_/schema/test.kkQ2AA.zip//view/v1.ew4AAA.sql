create definer = root@localhost view v1 as
select `test`.`user`.`id` AS `id`, `test`.`user`.`name` AS `name`, `test`.`user`.`age` AS `age`
from `test`.`user`
where (`test`.`user`.`id` >= 15);

-- comment on column v1.name not supported: 姓名

