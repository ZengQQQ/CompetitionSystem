create
    definer = root@localhost function f1(start int) returns int deterministic
begin
  declare sum int default 0;
  while start>0 do
  set sum:=sum+start;
  set start:=start-1;
  end while;
  return sum;
end;

