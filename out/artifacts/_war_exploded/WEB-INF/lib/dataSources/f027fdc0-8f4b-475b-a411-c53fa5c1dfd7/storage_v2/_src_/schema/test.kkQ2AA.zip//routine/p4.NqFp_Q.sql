create
    definer = root@localhost procedure p4(IN start int)
begin
    declare sum int default 0;
    repeat
    set sum:=start+sum;
    set start:=start-1;
    until start=0 #注意until后面没有分号
    end repeat;
    select sum;
end;

