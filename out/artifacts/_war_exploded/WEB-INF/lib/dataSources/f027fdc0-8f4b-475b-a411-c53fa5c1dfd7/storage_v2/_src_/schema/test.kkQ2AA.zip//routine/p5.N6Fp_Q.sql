create
    definer = root@localhost procedure p5(IN start int)
begin
    declare sum int default 0;
    #loop循环的前面和结尾要定义标签名，以配合leave语句和iterate语句
    label:loop
    #leave语句，实现循环停止
    if start=0 then
    leave label;
    end if;
    #iterate语句,实现遇到偶数时跳过循环
    if start%2=0 then
    set start:=start-1;
    iterate label;
    end if;
    set sum:=sum+start;
    set start=start-1;
    end loop ;
    select sum;
end;

