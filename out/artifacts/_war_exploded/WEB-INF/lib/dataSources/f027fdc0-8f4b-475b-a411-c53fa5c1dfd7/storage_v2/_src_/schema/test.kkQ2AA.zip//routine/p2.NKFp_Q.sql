create
    definer = root@localhost procedure p2(IN i int)
begin
    declare a int;
    declare s int;
    declare result varchar(10);
    select age into a from user where id=i;
    select score into s from user where id=i;
    case
        when s>=60 and a<22 then
        set result:='通过';
        when s>=80 and a<22 then
        set result:='转正';
        when s>=90 and a>=22 then
        set result:='晋升';
    end case;
    select result;
end;

