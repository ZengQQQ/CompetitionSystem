create definer = root@localhost trigger t_delete
    after delete
    on user
    for each row
begin
        insert into user_logs values (null,'删除',now(),concat('删除的id为 ',OLD.id,'\n','删除的姓名为 ',OLD.name,'\n','删除的年龄为 ',OLD.age));
    end;

