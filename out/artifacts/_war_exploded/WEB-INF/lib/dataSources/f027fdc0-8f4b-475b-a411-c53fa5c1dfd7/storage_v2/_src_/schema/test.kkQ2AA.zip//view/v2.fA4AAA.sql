create definer = root@localhost view v2 as
select `test`.`v1`.`id` AS `id`, `test`.`v1`.`name` AS `name`, `test`.`v1`.`age` AS `age`
from `test`.`v1`
where (`test`.`v1`.`id` <= 20);

-- comment on column v2.name not supported: 姓名

