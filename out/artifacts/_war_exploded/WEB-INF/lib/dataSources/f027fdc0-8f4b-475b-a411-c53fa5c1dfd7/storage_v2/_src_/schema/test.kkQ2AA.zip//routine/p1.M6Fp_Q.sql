create
    definer = root@localhost procedure p1(IN i int, OUT result varchar(10))
begin
    declare s int default 60;
    select score into s from test.user where id=i;
    if s<60 then
    set result:='不及格';
    elseif s>=60 and s<90 then
    set result:='及格';
    else
    set result:='优秀';
    end if;
end;

