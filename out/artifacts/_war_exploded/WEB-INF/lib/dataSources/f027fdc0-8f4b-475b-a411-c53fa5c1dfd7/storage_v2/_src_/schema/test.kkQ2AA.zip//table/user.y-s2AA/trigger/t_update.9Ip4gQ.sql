create definer = root@localhost trigger t_update
    after update
    on user
    for each row
begin
    insert into user_logs values (null,'修改',now(),concat('修改前的姓名为 ',OLD.name,' 新姓名为 ',new.name,'\n',
        '修改前的年龄为 ',OLD.age,' 新年龄为 ',NEW.age));
    end;

