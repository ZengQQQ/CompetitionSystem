create definer = root@localhost trigger t_insert
    after insert
    on user
    for each row
begin
      insert into user_logs values (null,'添加',now(),concat('插入的姓名为 ',new.name,'插入的年龄为 ',new.age)); #now()表示得到此时的时间
    end;

