create
    definer = root@localhost procedure p3(IN start int)
begin
    declare sum int default 0;
    while start>0 do
    set sum:=sum+start;
    set start:=start-1;
    end while;
    select sum;
end;

